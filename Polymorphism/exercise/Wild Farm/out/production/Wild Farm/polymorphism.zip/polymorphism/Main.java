package polymorphism;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
        List<Animal> animals = new ArrayList<>();


        while (true) {

            String[] inputAnimal = bfr.readLine().split("\\s+");

            if (inputAnimal[0].equals("End")) {
                break;
            }
            String[] inputFood = bfr.readLine().split("\\s+");


            String typeFood = inputFood[0];
            Integer quantity = Integer.parseInt(inputFood[1]);


            Food food;
            if (typeFood.equals("Vegetable")) {
                food = new Vegetable(quantity);
            } else {
                food = new Meat(quantity);

            }


            // Animal information

            String animalType = inputAnimal[0];
            String animalName = inputAnimal[1];
            Double animalWeight = Double.parseDouble(inputAnimal[2]);
            String animalLivingRegion = inputAnimal[3];


            switch (animalType) {

                case "Mouse":
                    Mouse mouse = new Mouse(animalName, animalType, animalWeight, 0, animalLivingRegion);

                    try {

                       mouse.makeSound();
                       mouse.eat(food);

                    } catch (IllegalArgumentException exception) {
                        System.out.println(exception.getMessage());
                    }
                    animals.add(mouse);

                    break;

                case "Zebra":
                    Zebra zebra = new Zebra(animalName, animalType, animalWeight, 0, animalLivingRegion);

                    try {
                        zebra.makeSound();
                        zebra.eat(food);
                    } catch (IllegalArgumentException exception) {
                        System.out.println(exception.getMessage());
                    }
                    animals.add(zebra);
                    break;




                case "Cat":
                    String catBreed = inputAnimal[4];
                    Cat cat = new Cat(animalName, animalType, animalWeight, 0, animalLivingRegion, catBreed);

                    try {
                        cat.makeSound();
                        cat.eat(food);


                    } catch (IllegalArgumentException exception) {
                        System.out.println(exception.getMessage());
                    }
                    animals.add(cat);
                    break;

                case "Tiger":
                    Tiger tiger = new Tiger(animalName, animalType, animalWeight, 0, animalLivingRegion);

                    try {
                        tiger.makeSound();
                        tiger.eat(food);


                    } catch (IllegalArgumentException exception) {
                        System.out.println(exception.getMessage());
                    }
                    animals.add(tiger);
                    break;
            }
        }

        printAnimals(animals);

    }



    public static void printAnimals(List<Animal> animals){

        for (Animal animal : animals) {
            System.out.println(animal.toString());

        }
    }

}
