package polymorphism;

public class Meat extends Food{
    protected Meat(Integer quantity) {
        super(quantity);
    }
}
