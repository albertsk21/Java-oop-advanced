package polymorphism;

public abstract class Felime extends Mammal{




    protected Felime(String animalName, String animalType, Double animalWeight, Integer foodEaten, String livingRegion) {
        super(animalName, animalType, animalWeight, foodEaten, livingRegion);
   
    }

}
