package polymorphism;

public class Car extends Vehicle{

    public Car(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        super(fuelQuantity, fuelConsumptionInLitersPerKm);
    }

    @Override
    void drive(double distance) {
        double mainConsumption = distance * (this.getFuelConsumptionInLitersPerKm() + 0.9);

        if(mainConsumption <= this.getFuelQuantity()){
            this.setFuelQuantity(this.getFuelQuantity() - mainConsumption);
            System.out.printf("The car travelled %.0f km%n",distance);
        }else{
            System.out.println("The car needs refueling");
        }

    }

    @Override
    void refuelling(double refuellingLiters) {
        this.setFuelQuantity(this.getFuelQuantity() + refuellingLiters );
    }


}
