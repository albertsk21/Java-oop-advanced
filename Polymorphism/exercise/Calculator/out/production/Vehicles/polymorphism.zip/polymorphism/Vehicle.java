package polymorphism;

public abstract class Vehicle {

    private double fuelQuantity;
    private final double fuelConsumptionInLitersPerKm;



    protected Vehicle(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm;
    }


    abstract void drive(double distance);
    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;

    }

    public double getFuelConsumptionInLitersPerKm() {
        return fuelConsumptionInLitersPerKm;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    abstract void refuelling(double refuellingLiters);

}
