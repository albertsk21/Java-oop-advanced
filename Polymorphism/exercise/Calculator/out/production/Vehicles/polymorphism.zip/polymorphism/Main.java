package polymorphism;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader bfr =  new BufferedReader( new InputStreamReader(System.in));


        //---INPUT-CAR---//
        String[] input = bfr.readLine().split(" ");
        double carFuelQuantity = Double.parseDouble(input[1]);
        double carLitersPerKm = Double.parseDouble(input[2]);

        Vehicle car = new Car(carFuelQuantity,carLitersPerKm);

        //---INPUT-TRUCK---//
        input = bfr.readLine().split(" ");

        double truckFuelQuantity = Double.parseDouble(input[1]);
        double truckLitersPerKm = Double.parseDouble(input[2]);
        Vehicle truck =  new Truck(truckFuelQuantity,truckLitersPerKm);


        int iteration = Integer.parseInt(bfr.readLine());

        for (int i = 0; i < iteration; i++) {

            input = bfr.readLine().split(" ");

            if(input[0].equals("Drive") ){


                if( input[1].equals("Car")){
                    double distance = Double.parseDouble(input[2]);
                    car.drive(distance);

                }else if( input[1].equals("Truck")){
                    double distance = Double.parseDouble(input[2]);
                    truck.drive(distance);

                }


            }else if(input[0].equals("Refuel")){

                if(input[1].equals("Car")){
                    double refuelingLiters = Double.parseDouble(input[2]);
                    car.refuelling(refuelingLiters);

                }else if(input[1].equals("Truck")){
                    double refuelingLiters = Double.parseDouble(input[2]);
                    truck.refuelling(refuelingLiters);

                }

            }

        }


        System.out.printf("Car: %.2f%n",car.getFuelQuantity());
        System.out.printf("Truck: %.2f%n",truck.getFuelQuantity());

    }

}
