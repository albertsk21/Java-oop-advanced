package polymorphism;

public class Truck extends Vehicle {

    public Truck(double fuelQuantity, double fuelConsumptionInLitersPerKm) {
        super(fuelQuantity, fuelConsumptionInLitersPerKm);
    }

    @Override
    void drive(double distance) {
        double mainConsumption = distance * (this.getFuelConsumptionInLitersPerKm() + 1.6);

        if(mainConsumption <= this.getFuelQuantity()){
            this.setFuelQuantity(this.getFuelQuantity() - mainConsumption);
            System.out.printf("The truck travelled %.0f km%n",distance);
        }else{
            System.out.println("The truck needs refueling");
        }

    }

    @Override
    void refuelling(double refuellingLiters){
        this.setFuelQuantity(this.getFuelQuantity() + refuellingLiters * 0.95);
    }


}
