public class Topping {


    private String toppingType;
    private double weight;


    //---CONSTRUCTOR---//
    public Topping(String toppingType, double weight){
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    //---SETTERS---//
    public void setToppingType(String toppingType) {

        switch (toppingType) {
            case "Meat":
            case "Veggies":
            case "Cheese":
            case "Sauce":
                break;
            default:
                throw new IllegalArgumentException(String.format("Cannot place %s on top of your pizza", toppingType));
        }
        this.toppingType = toppingType;
    }
    public void setWeight(double weight) {
        if(!(weight >= 1 && weight <= 50 )){
            throw new IllegalArgumentException(String.format("%s weight should be in the range (1..50)",this.getToppingType()));
        }
        this.weight = weight;
    }

    //---GETTERS---//
    public double getWeight() {
        return weight;
    }
    public double getToppingType() {
        double grams = 0;
        switch (this.toppingType) {
            case "Meat":
                grams = 1.2;
                break;
            case "Veggies":
                grams = 0.8;
                break;
            case "Cheese":
                grams = 1.1;
                break;
            case "Sauce":
                grams = 0.9;
                break;
        }

        return grams;
    }
    public double getResultCalories(){
        return (2 * this.getWeight()) * this.getToppingType();
    }

}
