package borderControl;

public class Robot extends Identifier implements Identifiable{


    private String model;

    public Robot(String id, String model) {
        super(id);
        this.model = model;
    }

    @Override
    public String getId() {
        return super.getId();
    }

    public String getModel() {
        return model;
    }
}
