package borderControl;

public class Citizen extends Identifier{

    private String name;
    private int age;

    public Citizen(String id, String name, int age) {
        super(id);
        this.name = name;
        this.age = age;

    }


    @Override
    public String getId() {
        return super.getId();
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
