package ferrari;

public interface Car {
   String brakes();
   String gas();

}
