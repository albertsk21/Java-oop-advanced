public class Tracker {


    @Author (name = "Peter")
    public static void printMethodsByAuthor(Class<?> cl){

    }
}
