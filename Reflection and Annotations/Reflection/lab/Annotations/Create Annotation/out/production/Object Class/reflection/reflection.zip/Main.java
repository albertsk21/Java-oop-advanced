package reflection;

import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {


        Class<Reflection> reflectionClass = Reflection.class;
        System.out.println(reflectionClass);
        System.out.println(reflectionClass.getSuperclass());
        Class[]  interfaces = reflectionClass.getInterfaces();
        for (Class<?> anInterfaces : interfaces) {
            System.out.println(anInterfaces);
        }

        Reflection reflection = reflectionClass.getDeclaredConstructor().newInstance();
        System.out.println(reflection);
    }
}
