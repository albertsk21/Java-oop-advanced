@Subject(categories = {"Test", "Annotations"})
public class TestClass {

}
