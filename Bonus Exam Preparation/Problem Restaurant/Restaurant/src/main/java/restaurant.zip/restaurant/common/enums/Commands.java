package restaurant.common.enums;

public enum Commands {
    addHealthyFood,
    addBeverage,
    addTable,
    reserve,
    orderHealthyFood ,
    orderBeverage ,
    closedBill,
    totalMoney,
    END
}
