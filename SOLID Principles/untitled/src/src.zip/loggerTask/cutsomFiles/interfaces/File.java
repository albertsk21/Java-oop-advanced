package loggerTask.cutsomFiles.interfaces;

public interface File {

    int getSize();
    void write();
    void appendBuffer(String text);

}
