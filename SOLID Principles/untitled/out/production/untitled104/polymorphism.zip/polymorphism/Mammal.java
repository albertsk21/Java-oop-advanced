package polymorphism;
import java.text.DecimalFormat;

public abstract class Mammal extends Animal {
    private String livingRegion;
    public Mammal(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight);
        this.livingRegion = livingRegion;
    }
    public String getLivingRegion() {
        return livingRegion;
    }
    public void setLivingRegion(String livingRegion) {
        this.livingRegion = livingRegion;
    }
    @Override
    public String toString() {
        DecimalFormat decimalFormat = new DecimalFormat("0.##########");
        if(this instanceof Cat cat){
            return String.format( "Cat[%s, %s, %s, %s, %d]",cat.getAnimalName(),cat.getBreed(),decimalFormat.format(cat.getAnimalWeight()),cat.getLivingRegion() ,cat.getFoodEaten());
        }
        return String.format( "%s[%s, %s, %s, %d]",this.getClass().getSimpleName(),this.getAnimalName(),decimalFormat.format(this.getAnimalWeight()),this.getLivingRegion(),this.getFoodEaten());
    }
}
