package polymorphism;


public class Zebra extends Mammal {
    public Zebra(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }


    @Override
    void makeSound() {
        System.out.println("Zs");
    }

    @Override
    void eat(Food food) {
        if(food instanceof Vegetable){
            super.setFoodEaten(super.getFoodEaten() + food.getQuality());
        }else{
            System.out.println("The type of food cannot be consumed by Zebras");
        }

    }
}
