package polymorphism;



public class Tiger extends Felime {
    private String livingRegion;
    public Tiger(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight,  livingRegion);
        this.livingRegion = livingRegion;
    }

    @Override
    public String getLivingRegion() {
        return livingRegion;
    }

    @Override
    void makeSound() {
        System.out.println("ROAAR!!!");
    }

    @Override
    public void setLivingRegion(String livingRegion) {
        this.livingRegion = livingRegion;
    }

    @Override
    void eat(Food food) {
        if(food instanceof Meat){
            super.setFoodEaten(super.getFoodEaten() + food.getQuality());
        }else{
            System.out.println("The type of food cannot be consumed by Tigers");
        }
    }
}
