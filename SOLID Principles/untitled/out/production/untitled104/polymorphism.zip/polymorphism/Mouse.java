package polymorphism;



public class Mouse extends Mammal {


    public Mouse(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }


    @Override
    void makeSound() {
        System.out.println("SQUEEEAAAK!");
    }

    @Override
    void eat(Food food) {
        if(food instanceof Vegetable){
            super.setFoodEaten(super.getFoodEaten() + food.getQuality());
        }else{
            System.out.println("The type of food cannot be consumed by Mouses");
        }

    }
}
