package polymorphism;

public abstract class Food {
    private int quality;

    public Food(int quality) {
        this.quality = quality;
    }

    public int getQuality() {
        return quality;
    }

    public void setQuality(int quality) {
        this.quality = quality;
    }
}
