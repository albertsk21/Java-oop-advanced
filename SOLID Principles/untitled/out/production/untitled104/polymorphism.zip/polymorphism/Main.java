package polymorphism;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));


        String[] line = bfr.readLine().split("\\s+");

        List<Mammal> mammals = new ArrayList<>();

        int counterIteration = 0;
        while (!"End".equals(line[0])){

            if (counterIteration % 2 == 0) {
                addAnimal(mammals,line);
            }else {
                feedLastAnimal(line,mammals);
            }

            counterIteration++;
            line = bfr.readLine().split("\\s+");
        }
        printAnimals(mammals);

    }

    private static void feedLastAnimal(String[] read, List<Mammal> mammals){
        switch (read[0]){
            case "Vegetable" -> {
                Vegetable vegetable = new Vegetable(Integer.parseInt(read[1]));
                mammals.get(mammals.size() - 1).eat(vegetable);
            }
            case "Meat" ->{
                Meat meat = new Meat(Integer.parseInt(read[1]));
                mammals.get(mammals.size() - 1).eat(meat);
            }
        }
    }
    private static void addAnimal(List<Mammal> mammals, String[] line){
        switch (line[0]) {
            case "Mouse" -> {
                Mouse mouse = new Mouse(line[1], line[0], Double.parseDouble(line[2]), line[3]);
                mouse.makeSound();
                mammals.add(mouse);
            }
            case "Zebra" -> {
                Zebra zebra = new Zebra(line[1], line[0], Double.parseDouble(line[2]), line[3]);
                zebra.makeSound();
                mammals.add(zebra);
            }
            case "Cat" -> {
                Cat cat = new Cat(line[1],line[0],Double.parseDouble(line[2]),line[3],line[4]);
                cat.makeSound();
                mammals.add(cat);
            }
            case "Tiger" -> {
                Tiger tiger = new Tiger(line[1], line[0], Double.parseDouble(line[2]), line[3]);
                tiger.makeSound();
                mammals.add(tiger);
            }
        }
    }
    private static void printAnimals(List<Mammal> mammals){
        for (Mammal mammal: mammals) {
            System.out.println(mammal.toString());
        }
    }
}
