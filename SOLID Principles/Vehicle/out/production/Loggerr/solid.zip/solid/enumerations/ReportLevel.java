package solid.enumerations;

public enum ReportLevel {

    INFO,
    WARNING,
    ERROR,
    CRITICAL,
    FATAL,
}
