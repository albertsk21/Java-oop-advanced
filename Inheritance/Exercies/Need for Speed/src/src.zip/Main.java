public class Main {

    public static void main(String[] args) {



            FamilyCar familyCar =  new FamilyCar(10.5, 14);
            familyCar.drive(10);
        System.out.println(familyCar.getFuel());
    }
}
