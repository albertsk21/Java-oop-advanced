public class CrossMotorcycle extends Motorcycle{

    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }

    @Override
    public void setFuelConsumption(double fuelConsumption) {
        super.setFuelConsumption(fuelConsumption);
    }
}
