public class Main {

    public static void main(String[] args) {



        RaceMotorcycle raceMotorcycle =  new RaceMotorcycle(20.5, 14);

        System.out.println(raceMotorcycle.getFuelConsumption());
    }
}
