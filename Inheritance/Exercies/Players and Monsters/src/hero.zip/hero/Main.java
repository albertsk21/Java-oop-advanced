package hero;

public class Main {

    public static void main(String[] args) {



        DarkKnight darkKnight=  new DarkKnight("ab3rtsk21",999);

        System.out.println(darkKnight);
    }
}
